export default defineNuxtRouteMiddleware((to, from) => {
    console.log("Log")
    
})