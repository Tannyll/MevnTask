module.exports.Appointments = require("./Appointments");
module.exports.Users = require("./Users");



