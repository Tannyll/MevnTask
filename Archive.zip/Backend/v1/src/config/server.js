const dotenv = require('dotenv');

module.exports = () => {
    dotenv.config();
}