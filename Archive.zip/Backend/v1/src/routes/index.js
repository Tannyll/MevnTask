module.exports.AppointmentRoutes = require("./Appointments");
module.exports.UserRoutes = require("./Users");
module.exports.HomeRoutes = require("./Home");


